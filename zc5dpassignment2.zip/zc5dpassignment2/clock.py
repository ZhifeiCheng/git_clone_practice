from time import time, sleep, localtime


class Clock:
    def __init__(self, hour=0, minute=0, second=0):
        self._hour = hour
        self._minute = minute
        self._second = second

    def __str__(self):
        return str(f'{self._hour:02}:{self._minute:02}:{self._second:02}')

    def hour(self):
        return self._hour

    def minute(self):
        return self._minute

    def second(self):
        return self._second

    def set_hour(self, new_hour: int):
        if new_hour < 0 or new_hour > 23:
            raise ValueError("input an integer number from 0 through 23")
        self._hour = new_hour

    def set_minute(self, new_minute: int):
        if new_minute < 0 or new_minute > 59:
            raise ValueError("input an integer number from 0 through 59")
        self._minute = new_minute

    def set_second(self, new_second: int):
        if new_second < 0 or new_second > 59:
            raise ValueError("input an integer number from 0 through 59")
        self._second = new_second

    def advance_hour(self, amount_to_advance: int):
        if amount_to_advance < 0:
            raise ValueError("input an integer number larger than 0")
        self._hour = (self._hour + amount_to_advance) % 24
        return self._hour

    def advance_minute(self, amount_to_advance: int):
        if amount_to_advance < 0:
            raise ValueError("input an integer number larger than 0")
        self.advance_hour(amount_to_advance // 60)
        self._minute = (self._minute + amount_to_advance) % 60
        return self._minute

    def advance_second(self, amount_to_advance: int):
        if amount_to_advance < 0:
            raise ValueError("input an integer number larger than 0")
        self.advance_minute(amount_to_advance // 60)
        self._second = (self._second + amount_to_advance) % 60
        return self._second

    def set_to_current_time(self):
        current_time = localtime(time())
        self._hour = current_time.tm_hour
        self._minute = current_time.tm_min
        self._second = current_time.tm_sec

    def __lt__(self, other):
        if not isinstance(other, Clock):
            raise TypeError("Input expects a valid Clock instance")
        return self.__str__() < other.__str__()

    def __eq__(self, other):
        if not isinstance(other, Clock):
            raise TypeError("Input expects a valid Clock instance")
        return self.__str__() == other.__str__()

    def __gt__(self, other):
        if not isinstance(other, Clock):
            raise TypeError("Input expects a valid Clock instance")
        return self.__str__() > other.__str__()


if __name__ == "__main__":
    clock1 = Clock(23, 10, 32)
    clock2 = Clock(23, 11, 32)
    clock3 = Clock(20, 10, 32)
    list = [clock2, clock1, clock3]
    list.sort()
    for clk in list:
        print(clk)

