Zhifei Cheng

Estimated time: 12h

Problem: how to sort strings

	 how to utilize quick sort to sort clocks
