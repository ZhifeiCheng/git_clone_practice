from clock import Clock


class ClockShop:
    def __init__(self):
        self.__clocks = []

    def fill_clock_shop(self,  list_of_times):
        for clock_time in list_of_times:
            clock_hour_int = int(clock_time.split(":")[0])
            clock_minute_int = int(clock_time.split(":")[1])
            clock_second_int = int(clock_time.split(":")[2])
            self.__clocks.append(Clock(clock_hour_int, clock_minute_int, clock_second_int))

    @classmethod
    def quick_sort(cls, lst, low, high):
        s_idx = low
        e_idx = high
        p = e_idx
        if high > low + 1:
            while s_idx < e_idx:
                if lst[s_idx] < lst[p] or lst[s_idx] == lst[p]:
                    s_idx += 1
                else:
                    if lst[e_idx] < lst[p]:
                        lst[s_idx], lst[e_idx] = lst[e_idx], lst[s_idx]
                    else:
                        e_idx -= 1
            else:
                lst[e_idx], lst[p] = lst[p], lst[e_idx]
            ClockShop.quick_sort(lst, low, e_idx-1)
            ClockShop.quick_sort(lst, e_idx+1, high)

    def sort_clocks(self):
        ClockShop.quick_sort(self.__clocks, 0, len(self.__clocks)-1)

    def find_clock(self, a_clock: Clock):
        for idx in range(len(self.__clocks)):
            if a_clock == self.__clocks[idx]:
                return idx
        return -1

    def __str__(self):
        output = ""
        for clock in self.__clocks:
            output += clock.__str__()+"\n"
        return output

    def get_clock(self, index: int) -> Clock:
        if index < 0 or index >= len(self.__clocks):
            raise ValueError("input a valid integer as index")
        return self.__clocks[index]

    def set_clock(self, a_clock: Clock, index: int):
        if index < 0 or index >= len(self.__clocks):
            raise ValueError("input a valid integer as index")
        self.__clocks[index] = a_clock



